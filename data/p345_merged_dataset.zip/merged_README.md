# 概念合并后的事故资料

主表merged_incidents.csv保留1,550份报告、32列，每行一份，369份伴随伤亡。PRESSURE_PC1是三项压力的共同得分，无量纲；AGE_YEARS是年龄，按事故发生年减安装年表示服役年数，单位为年，1,268份有效。76份同时记载安装年和制造年的报告用于检验共同年龄概念，主表保留全部报告。钢管尺寸的配对PCA有274份，单轴保留82.5%的标准化变异；PIPE_DIAMETER与WT_STEEL分别保留，单位均为英寸。

merged_components.csv保留三项原始压力、两项原始年龄、配对年龄主成分及合并字段，便于逐份核对。原始压力高于允许上限的38份记录在此对照表保留。AGE_PC1_PAIRED为无量纲得分，仅对76份配对记录计算。

merged_dictionary.csv解释主表各字段、单位与有效数量；merged_models.json给出本次使用的投影参数；merged_metadata.json记录范围、缺失规则及核对结果。CSV使用UTF-8 BOM，可用Excel或Python打开，空白代表原资料缺失。

before_merge_incidents.csv保留同一批报告在概念合并前的35列分析字段；field_comparison.csv完整列出处理前后的字段、有值份数、有值率和未知份数。合并后的32列包括编号、日期和结果，不全是模型输入。

这是一份描述性分析资料。原因、点燃和爆炸字段描述事故过程；实际预测时应另按信息可得时点选择输入，并在训练集内拟合预处理。现有DBSCAN独立计算。
