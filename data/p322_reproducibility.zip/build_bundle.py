"""Package existing analysis artifacts and verify an isolated extraction."""
from pathlib import Path
import csv
import hashlib
import io
import json
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE if (HERE / "work/p322_completion/models").is_dir() else HERE.parents[2]
MODEL_DIR = "work/p322_completion/models"
MODEL_FILES = [
    "complete_models.py", "supplement_checks.py", "verify_artifacts.py",
    "protocol.md", "protocol_receipt.json", "execution_receipt.json", "supplement_receipt.json",
    "cohort693.csv", "input_model_parameters.json", "input_validation_predictions.csv",
    "input_later_predictions.csv", "cluster_models_parameters.json",
    "cluster_validation_predictions.csv", "cluster_later_predictions.csv",
    "cluster_preprocessing.json", "calibration_parameters.json",
    "calibration_validation_predictions.csv", "calibration_later_predictions.csv",
    "selection_frozen.json", "input_selection_early_only.csv",
    "raw_calibrated_later_all_records.csv", "final_classification_counts.json",
    "proposal_four_method_reference.csv", "proposal_four_method_predictions.csv",
    "final_model.json", "steel_plastic_reuse.json",
]
PREVIOUS_FILES = [
    "run_trials.py", "A_cohort_records.csv", "A_later_predictions.csv",
    "B_later_predictions.csv", "B_metrics.csv", "B_paired_operator_intervals.csv",
]
COPY_PATHS = [
    *[f"{MODEL_DIR}/{name}" for name in MODEL_FILES],
    *[f"work/p320_core/prediction/{name}" for name in PREVIOUS_FILES],
    "research/results/course_visual_lab_20261109/clustering/physical_frozen_parameters.json",
    "research/results/course_visual_lab_20261109/clustering/physical_records_693.csv",
    "research/results/course_sweep_20261107/models/model_metrics.csv",
    "research/results/course_sweep_20261107/models/later_predictions.csv",
    "research/analysis/study_common.py", "research/results/analysis_primary.csv",
]


def encoded_json(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    contents = {name: (ROOT / name).read_bytes() for name in COPY_PATHS}
    for name in ["README.md", "requirements.txt", "build_bundle.py"]:
        contents[name] = (HERE / name).read_bytes()
    sources = json.loads((ROOT / "research/inputs/sources.json").read_text(encoding="utf-8"))
    primary = next(f for f in sources["files"] if f["path"] == "inputs/data/incident_primary.zip")
    contents["research/inputs/sources.json"] = encoded_json({
        "locked_on": sources["locked_on"],
        "incident_information_page": sources["incident_information_page"],
        "files": [primary],
    })
    for name, data in contents.items():
        if name.endswith(".csv"):
            header = next(csv.reader(io.StringIO(data.decode("utf-8-sig"))))
            forbidden = [field for field in header if any(part in field.upper() for part in
                         ["EMAIL", "TELEPHONE", "CONTACT", "PREPARER", "AUTHORIZER", "NARRATIVE", "STREET_ADDRESS"])]
            if forbidden:
                raise ValueError(f"Excluded personal-data fields in {name}: {forbidden}")
    contents["MANIFEST.json"] = encoded_json({
        "scope": "existing analysis artifacts; official raw archive excluded; no model refits",
        "sources_manifest": "primary-data entry only; original raw-data SHA-256 retained",
        "files": [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                  for name, data in sorted(contents.items())],
    })
    archive = HERE / "p322_reproducibility.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in sorted(contents.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(info, data, compresslevel=9)
    with tempfile.TemporaryDirectory(prefix="verify-", dir=HERE) as directory:
        extracted = Path(directory)
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(extracted)
        manifest = json.loads((extracted / "MANIFEST.json").read_text(encoding="utf-8"))
        for row in manifest["files"]:
            data = (extracted / row["path"]).read_bytes()
            assert len(data) == row["bytes"]
            assert hashlib.sha256(data).hexdigest() == row["sha256"]
        imports = subprocess.run(
            [sys.executable, "-X", "utf8", "-c",
             "import runpy,sys\nfor path in sys.argv[1:]: runpy.run_path(path)",
             str(extracted / MODEL_DIR / "complete_models.py"),
             str(extracted / MODEL_DIR / "supplement_checks.py")],
            cwd=extracted, capture_output=True, text=True, encoding="utf-8", timeout=60,
        )
        if imports.returncode:
            raise RuntimeError(f"Extracted entry-point imports failed:\n{imports.stdout}\n{imports.stderr}")
        result = subprocess.run(
            [sys.executable, "-X", "utf8", str(extracted / MODEL_DIR / "verify_artifacts.py")],
            cwd=extracted, capture_output=True, text=True, encoding="utf-8", timeout=60,
        )
        if result.returncode:
            raise RuntimeError(f"Extracted verification failed:\n{result.stdout}\n{result.stderr}")
        verification = json.loads((extracted / MODEL_DIR / "verification.json").read_text(encoding="utf-8"))
    report = {
        "archive": archive.name, "bytes": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "packaged_files": len(contents), "manifest_hashes_verified": True,
        "entrypoint_imports_verified": True,
        "verification_exit_code": result.returncode,
        "verification": verification,
    }
    (HERE / "bundle_verification.json").write_bytes(encoded_json(report))
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
