"""Bounded retrospective input and material-pooling checks; writes beside this file."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import platform
import sys
import warnings

import numpy as np
import pandas as pd
import sklearn
from scipy.special import expit
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from threadpoolctl import threadpool_limits

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "research/analysis"))
from study_common import load_data

SEED = 20261111
C = 0.2
BOOTSTRAPS = 2000
CAT = ["part", "mat", "location", "cls"]
PHYS = ["age_years", "log_diameter", "log_pressure"]
DP = ["log_diameter", "log_pressure"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cast(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return value.as_posix()
    raise TypeError(type(value).__name__)


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                     default=cast, allow_nan=False) + "\n", encoding="utf-8")


def csv(name, rows):
    pd.DataFrame(rows).to_csv(OUT / name, index=False, encoding="utf-8-sig")


def prepare():
    d = load_data()
    assert d.REPORT_NUMBER.is_unique
    d["part"] = d.SYSTEM_PART_INVOLVED.replace("", "UNKNOWN")
    d["mat"] = d.MATERIAL_INVOLVED.replace("", "UNKNOWN")
    d["location"] = d.LOCATION_TYPE.replace("", "UNKNOWN")
    d["cls"] = d.CLASS_LOCATION_TYPE.replace("", "UNKNOWN")
    age = d.incident_year - pd.to_numeric(d.INSTALLATION_YEAR, errors="coerce")
    diameter = pd.to_numeric(d.PIPE_DIAMETER, errors="coerce")
    pressure = pd.to_numeric(d.NORMAL_PSIG, errors="coerce")
    d["age_years"] = age.where(age.ge(0))
    d["diameter_in"] = diameter.where(diameter.gt(0))
    d["normal_psig"] = pressure.where(pressure.ge(0))
    d["log_diameter"] = np.log1p(d.diameter_in)
    d["log_pressure"] = np.log1p(d.normal_psig)
    d["month"] = pd.to_datetime(d.LOCAL_DATETIME, format="mixed").dt.month
    assert d.month.between(1, 12).all()
    d["month_sin"] = np.sin(2 * np.pi * (d.month - 1) / 12)
    d["month_cos"] = np.cos(2 * np.pi * (d.month - 1) / 12)
    d["complete_physical"] = d[PHYS].notna().all(axis=1)
    d["role"] = np.select([d.received_year.le(2017), d.received_year.le(2021)],
                          ["fit", "validation"], default="later")
    a = d[d.part.isin(["MAIN", "MAIN VALVE"]) &
          d.mat.isin(["CAST/WROUGHT IRON", "STEEL", "PLASTIC"]) &
          d.incident_year.between(2010, 2024)].copy()
    b = a[a.mat.isin(["STEEL", "PLASTIC"]) & a.CAUSE.eq("EXCAVATION DAMAGE")].copy()
    assert (len(a), int(a.cas.sum())) == (693, 141)
    assert (len(b), int(b.cas.sum())) == (391, 41)
    assert b.groupby("mat").agg(n=("cas", "size"), k=("cas", "sum")).to_dict() == {
        "n": {"PLASTIC": 195, "STEEL": 196}, "k": {"PLASTIC": 35, "STEEL": 6}}
    return d, a.sort_values("REPORT_NUMBER").reset_index(drop=True), b.sort_values("REPORT_NUMBER").reset_index(drop=True)


class FixedLogistic:
    def __init__(self, categorical=(), numeric=(), pcs=None, month=False, interactions=False):
        self.categorical, self.numeric = list(categorical), list(numeric)
        self.pcs, self.month, self.interactions = pcs, month, interactions

    def matrix(self, frame, training=False):
        arrays, names = [], []
        if self.categorical:
            if training:
                self.encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False).fit(frame[self.categorical])
            arrays.append(self.encoder.transform(frame[self.categorical]))
            names.extend(self.encoder.get_feature_names_out(self.categorical).tolist())
        if self.numeric:
            raw = frame[self.numeric].to_numpy(dtype=float)
            missing = np.isnan(raw).astype(float)
            if training:
                self.medians = np.nanmedian(raw, axis=0)
                assert np.isfinite(self.medians).all(), "Entirely missing numeric training column"
            imputed = np.where(np.isnan(raw), self.medians, raw)
            if training:
                self.scaler = StandardScaler().fit(imputed)
            z = self.scaler.transform(imputed)
            if self.pcs:
                if training:
                    self.pca = PCA(n_components=self.pcs, svd_solver="full").fit(z)
                values = self.pca.transform(z)
                value_names = [f"physical_PC{i + 1}" for i in range(self.pcs)]
            else:
                values, value_names = z, self.numeric
            arrays.extend([values, missing])
            names.extend(value_names + [f"missing_{f}" for f in self.numeric])
            if self.interactions:
                plastic = frame.mat.eq("PLASTIC").to_numpy(dtype=float)
                arrays.append(z * plastic[:, None])
                names.extend(["plastic_x_" + f for f in self.numeric])
        if self.month:
            arrays.append(frame[["month_sin", "month_cos"]].to_numpy())
            names.extend(["month_sin", "month_cos"])
        matrix = np.column_stack(arrays)
        assert np.isfinite(matrix).all()
        if training:
            self.feature_names = names
        else:
            assert self.feature_names == names
        return matrix

    def fit(self, frame):
        x = self.matrix(frame, training=True)
        assert frame.cas.nunique() == 2
        self.model = LogisticRegression(C=C, penalty="l2", solver="lbfgs", max_iter=5000,
                                        random_state=SEED).fit(x, frame.cas)
        self.train_n, self.train_k = len(frame), int(frame.cas.sum())
        return self

    def predict(self, frame):
        x = self.matrix(frame)
        p = self.model.predict_proba(x)[:, 1]
        assert np.max(np.abs(expit(self.model.intercept_[0] + x @ self.model.coef_[0]) - p)) < 1e-12
        return p

    def serialize(self):
        result = {"categorical": self.categorical, "numeric": self.numeric, "pcs": self.pcs,
                  "month": self.month, "interactions": self.interactions, "C": C,
                  "feature_names": self.feature_names, "coefficient": self.model.coef_[0],
                  "intercept": self.model.intercept_[0], "train_n": self.train_n,
                  "train_k": self.train_k, "iterations": self.model.n_iter_}
        if self.categorical:
            result["encoder_categories"] = [c.tolist() for c in self.encoder.categories_]
        if self.numeric:
            result.update(train_medians=self.medians, train_scale_mean=self.scaler.mean_, train_scale=self.scaler.scale_)
        if self.pcs:
            result.update(pca_components=self.pca.components_, pca_explained_variance_ratio=self.pca.explained_variance_ratio_,
                          pca_mean=self.pca.mean_, pca_training="Training period only, outcome unused; missing indicators retained separately")
        return result


def empirical(train, frame, column=None):
    rate = float(train.cas.mean())
    if column is None:
        return np.full(len(frame), rate), {"prevalence": rate}
    values = train.groupby(column).cas.mean()
    return frame[column].map(values).fillna(rate).to_numpy(), {"prevalence": rate, "rates": values.to_dict()}


def metrics(y, score):
    y, score = np.asarray(y, dtype=int), np.asarray(score, dtype=float)
    assert len(y) and np.isfinite(score).all() and ((score >= 0) & (score <= 1)).all()
    n, k = len(y), int(y.sum())
    take = int(np.ceil(.2 * n))
    cutoff = np.sort(score)[-take]
    above, tied = score > cutoff, score == cutoff
    slots = take - int(above.sum())
    hits = float(y[above].sum() + slots * y[tied].mean())
    two_classes = 0 < k < n
    clipped = np.clip(score, 1e-12, 1 - 1e-12)
    return {"n": n, "casualty_reports": k, "AP": float(average_precision_score(y, score)) if two_classes else None,
            "ROC_AUC": float(roc_auc_score(y, score)) if two_classes else None,
            "Brier": float(np.mean((y - score) ** 2)),
            "log_loss": float(-np.mean(y * np.log(clipped) + (1 - y) * np.log1p(-clipped))),
            "observed_fraction": k / n, "mean_probability": float(score.mean()),
            "budget20_n": take, "budget20_expected_hits": hits,
            "budget20_recall": hits / k if two_classes else None,
            "budget20_tie_min_hits": int(y[above].sum() + max(0, slots - int(tied.sum()) + int(y[tied].sum()))),
            "budget20_tie_max_hits": int(y[above].sum() + min(slots, int(y[tied].sum()))),
            "single_class": not two_classes}


def fit_predict(name, train, evaluate, experiment):
    if name in ["constant", "part_empirical", "material_empirical"]:
        col = {"constant": None, "part_empirical": "part", "material_empirical": "mat"}[name]
        return empirical(train, evaluate, col)
    if experiment == "A":
        options = {
            "categorical4": dict(categorical=CAT),
            "physical3": dict(numeric=PHYS),
            "combined7": dict(categorical=CAT, numeric=PHYS),
            "combined7_month": dict(categorical=CAT, numeric=PHYS, month=True),
            "physical_pca1": dict(numeric=PHYS, pcs=1),
            "physical_pca2": dict(numeric=PHYS, pcs=2),
        }
        model = FixedLogistic(**options[name]).fit(train)
        return model.predict(evaluate), model.serialize()
    if name == "separate_material":
        score = np.full(len(evaluate), np.nan)
        parameters = {}
        for material in ["STEEL", "PLASTIC"]:
            sample = train[train.mat.eq(material)]
            mask = evaluate.mat.eq(material).to_numpy()
            if sample.cas.nunique() < 2:
                raise ValueError("Single-class independent training: preserve counts; do not fit")
            model = FixedLogistic(numeric=DP).fit(sample)
            score[mask] = model.predict(evaluate.loc[mask])
            parameters[material] = model.serialize()
            parameters[material]["feasibility"] = "unstable_demonstration_only" if sample.cas.sum() < 10 else "sample_size_not_established"
        return score, parameters
    model = FixedLogistic(categorical=["mat"], numeric=DP,
                          interactions=name == "pooled_interaction").fit(train)
    return model.predict(evaluate), model.serialize()


def bootstrap(frame, predictions, pairs, experiment):
    operators = sorted(frame.OPERATOR_ID.unique())
    groups = [np.flatnonzero(frame.OPERATOR_ID.to_numpy() == name) for name in operators]
    rng = np.random.default_rng(SEED)
    y = frame.cas.to_numpy(dtype=int)
    point = {name: metrics(y, score) for name, score in predictions.items()}
    keys = ["AP", "Brier", "budget20_recall"]
    draws, invalid = [], 0
    for draw in range(BOOTSTRAPS):
        ix = np.concatenate([groups[i] for i in rng.integers(len(groups), size=len(groups))])
        if np.unique(y[ix]).size < 2:
            invalid += 1
            continue
        values = {name: metrics(y[ix], score[ix]) for name, score in predictions.items()}
        for left, right in pairs:
            draws.append({"draw": draw, "left": left, "right": right, "n": len(ix),
                          "casualty_reports": int(y[ix].sum()),
                          **{key: values[left][key] - values[right][key] for key in keys}})
    table = pd.DataFrame(draws)
    csv(f"{experiment}_paired_operator_draws.csv", table)
    intervals = []
    for left, right in pairs:
        part = table[table.left.eq(left) & table.right.eq(right)]
        for key in keys:
            lo, hi = part[key].quantile([.025, .975]).tolist()
            intervals.append({"left": left, "right": right, "metric": key,
                              "difference_left_minus_right": point[left][key] - point[right][key],
                              "ci_lower": lo, "ci_upper": hi, "valid_draws": BOOTSTRAPS - invalid,
                              "invalid_single_class_draws": invalid, "operators": len(operators),
                              "uncertainty_scope": "fixed predictions, operator resampling; no training refit"})
    csv(f"{experiment}_paired_operator_intervals.csv", intervals)
    return pd.DataFrame(intervals), {"requested": BOOTSTRAPS, "valid": BOOTSTRAPS - invalid, "single_class_skipped": invalid,
                                    "operators": len(operators)}


def run_experiment(experiment, frame, names, pairs):
    fitting = {"validation": frame[frame.role.eq("fit")], "later": frame[frame.received_year.le(2021)]}
    parameters, values, scores = {}, [], {}
    for role in ["validation", "later"]:
        train, test = fitting[role], frame[frame.role.eq(role)].copy().reset_index(drop=True)
        assert set(train.REPORT_NUMBER).isdisjoint(test.REPORT_NUMBER)
        table = test[["REPORT_NUMBER", "OPERATOR_ID", "incident_year", "received_year", "mat", "cas", "complete_physical"]].copy()
        parameters[role] = {}
        for name in names:
            score, fitted = fit_predict(name, train, test, experiment)
            assert len(score) == len(test) and np.isfinite(score).all()
            table["score_" + name] = score
            parameters[role][name] = fitted
            values.append({"method": name, "role": role, "material": "ALL", **metrics(test.cas, score)})
            if experiment == "B":
                for mat in ["STEEL", "PLASTIC"]:
                    select = test.mat.eq(mat).to_numpy()
                    values.append({"method": name, "role": role, "material": mat, **metrics(test.cas.to_numpy()[select], score[select])})
            if role == "later":
                scores[name] = score
        csv(f"{experiment}_{role}_predictions.csv", table)
    write_json(f"{experiment}_frozen_parameters.json", parameters)
    csv(f"{experiment}_metrics.csv", values)
    later = frame[frame.role.eq("later")].reset_index(drop=True)
    intervals, details = bootstrap(later, scores, pairs, experiment)
    return pd.DataFrame(values), intervals, parameters, details


def source_audit():
    old = ROOT / "research/results/course_sweep_20261107/models"
    physical = ROOT / "research/results/course_visual_lab_20261109/physical_prediction"
    ablation = ROOT / "research/results/course_visual_lab_20261109/ablation"
    sources = [
        old / "feature_subsets.csv", old / "feature_subset_predictions.csv", old / "paired_ablation_intervals.csv",
        old / "model_metrics.csv", old / "protocol.json", ablation / "paired_vs_part_intervals.csv",
        physical / "later_metrics.csv", physical / "later_predictions.csv", physical / "paired_operator_intervals.csv",
        physical / "protocol.json", ROOT / "research/analysis/course_sweep_models.py",
        ROOT / "research/analysis/course_visual_physical_prediction.py", ROOT / "research/analysis/course_visual_ablation.py",
        ROOT / "research/results/course_visual_lab_20261109/clustering/physical_records_693.csv",
        ROOT / "research/inputs/data/incident_primary.zip", ROOT / "research/results/analysis_primary.csv",
    ]
    inventory = [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha(p)} for p in sources]
    csv("source_inventory.csv", inventory)
    scores = pd.read_csv(old / "feature_subset_predictions.csv", dtype={"REPORT_NUMBER": str}, float_precision="round_trip")
    summaries = pd.read_csv(old / "feature_subsets.csv").set_index("features")
    check = []
    for name in summaries.index:
        measured = metrics(scores.cas, scores[name])
        for metric in ["AP", "Brier", "budget20_expected_hits"]:
            error = abs(measured[metric] - summaries.loc[name, metric])
            assert error < 1e-12
            check.append({"source": "categorical15", "method": name, "metric": metric, "absolute_error": error})
    ps = pd.read_csv(physical / "later_predictions.csv", dtype={"REPORT_NUMBER": str}, float_precision="round_trip")
    pm = pd.read_csv(physical / "later_metrics.csv").set_index("method")
    for name in pm.index:
        measured = metrics(ps.cas, ps["score_" + name])
        for metric in ["AP", "Brier"]:
            error = abs(measured[metric] - pm.loc[name, metric])
            assert error < 1e-12
            check.append({"source": "physical3", "method": name, "metric": metric, "absolute_error": error})
    csv("existing_prediction_readback.csv", check)
    csv("existing_categorical_ablation.csv", summaries.reset_index())
    csv("existing_physical_comparison.csv", pm.reset_index())
    old_delta = pd.read_csv(ablation / "paired_vs_part_intervals.csv")
    q = old_delta[old_delta.features.eq("part+mat+location+cls") & old_delta.metric.isin(["AP", "Brier"])]
    csv("existing_full_minus_part_intervals.csv", q)
    return inventory


def audit_cohorts(d, a, b):
    counts, missing, selections = [], [], []
    for name, frame in [("A", a), ("B", b)]:
        for role in ["fit", "validation", "refit", "later", "all"]:
            mask = (frame.received_year.le(2021) if role == "refit" else
                    pd.Series(True, index=frame.index) if role == "all" else frame.role.eq(role))
            part = frame[mask]
            for mat in ["ALL", *sorted(part.mat.unique())]:
                group = part if mat == "ALL" else part[part.mat.eq(mat)]
                counts.append({"experiment": name, "role": role, "material": mat, "n": len(group),
                               "casualty_reports": int(group.cas.sum()), "operators": group.OPERATOR_ID.nunique(),
                               "positive_operators": group.loc[group.cas.eq(1), "OPERATOR_ID"].nunique(),
                               "complete_physical_n": int(group.complete_physical.sum()),
                               "complete_physical_k": int(group.loc[group.complete_physical, "cas"].sum())})
                for field in ["age_years", "diameter_in", "normal_psig"]:
                    missing.append({"experiment": name, "role": role, "material": mat, "field": field,
                                    "n": len(group), "missing_n": int(group[field].isna().sum()),
                                    "missing_casualty_reports": int(group.loc[group[field].isna(), "cas"].sum())})
        csv(f"{name}_cohort_records.csv", frame[["REPORT_NUMBER", "OPERATOR_ID", "incident_year", "received_year", "role", "cas",
                                                *CAT, "age_years", "diameter_in", "normal_psig", "month", "complete_physical"]])
        for complete, group in frame.groupby("complete_physical"):
            for mat, subgroup in group.groupby("mat"):
                selections.append({"experiment": name, "complete_physical": bool(complete), "material": mat,
                                   "n": len(subgroup), "casualty_reports": int(subgroup.cas.sum())})
    csv("split_counts.csv", counts)
    csv("missingness.csv", missing)
    csv("complete_case_selection.csv", selections)
    timeline = []
    for name, frame in [("full1550", d), ("excavation391", b)]:
        for field in ["WORK_PERFORMED", "CAUSE", "CAUSE_DETAILS", "IGNITE_IND", "IGNITE_DATETIME", "INCIDENT_IDENTIFIED_DATETIME",
                      "CONFIRMED_DISCOVERY_DATETIME", "FATALITY_IND", "INJURY_IND"]:
            timeline.append({"cohort": name, "field": field, "n": len(frame), "nonblank": int(frame[field].ne("").sum())})
    csv("stage_field_completeness.csv", timeline)
    return pd.DataFrame(counts)


def noninferiority(intervals):
    rows = []
    pairs = intervals[["left", "right"]].drop_duplicates()
    for pair in pairs.itertuples(index=False):
        values = intervals[intervals.left.eq(pair.left) & intervals.right.eq(pair.right)].set_index("metric")
        if pair.right == "constant":
            continue
        for ap_margin in [.01, .03, .05]:
            rows.append({"candidate": pair.left, "reference": pair.right, "AP_margin": ap_margin, "Brier_margin": .01,
                         "AP_difference": values.loc["AP", "difference_left_minus_right"],
                         "AP_difference_ci_lower": values.loc["AP", "ci_lower"],
                         "Brier_difference": values.loc["Brier", "difference_left_minus_right"],
                         "Brier_difference_ci_upper": values.loc["Brier", "ci_upper"],
                         "passes_exploratory_joint_margin": bool(values.loc["AP", "ci_lower"] > -ap_margin and
                                                                 values.loc["Brier", "ci_upper"] < .01),
                         "claim_status": "illustrative retrospective criterion; no operational sufficiency established"})
    csv("A_exploratory_noninferiority.csv", rows)


def main():
    started = datetime.now(timezone.utc).isoformat()
    card_hash = sha(OUT / "experiment_card.md")
    inventory = source_audit()
    d, a, b = prepare()
    counts = audit_cohorts(d, a, b)
    write_json("run_protocol.json", {
        "written_before_new_fits_utc": datetime.now(timezone.utc).isoformat(),
        "experiment_card_sha256": card_hash, "seed": SEED, "C_fixed": C, "bootstrap_repetitions": BOOTSTRAPS,
        "data_split": {"fit": "received_year<=2017", "validation": "2018<=received_year<=2021",
                       "refit": "received_year<=2021", "later": "received_year>=2022", "incident_scope": "2010<=incident_year<=2024"},
        "later_outcomes_previously_studied": True, "prospective_validation": False,
        "forbidden_model_inputs": ["cas", "CAUSE", "CAUSE_DETAILS", "IGNITE_IND", "EXPLODE_IND", "FATALITY_IND", "INJURY_IND", "costs"],
        "month_encoding": "sin/cos of current month, no data-fitted cutoff", "missingness": "training numeric median plus all per-field missing indicators",
        "PCA": "training-only PCA on standardized median-imputed physical values; missing indicators appended outside PCA",
        "independent_steel_limit": "fewer than 10 training positives means instability demonstration only; this is not a universal sufficiency rule"})
    a_names = ["constant", "part_empirical", "categorical4", "physical3", "combined7", "combined7_month", "physical_pca1", "physical_pca2"]
    a_pairs = [(name, "combined7_month") for name in a_names if name != "combined7_month"] + [
        ("physical_pca1", "physical3"), ("physical_pca2", "physical3"), ("categorical4", "combined7"),
        ("physical3", "combined7"), ("physical3", "constant"), ("combined7", "constant")]
    am, ai, ap, ab = run_experiment("A", a, a_names, a_pairs)
    noninferiority(ai)
    print("A completed", json.dumps(am[am.role.eq("later")][["method", "n", "casualty_reports", "AP", "Brier"]].to_dict("records")), flush=True)
    b_names = ["constant", "part_empirical", "material_empirical", "pooled_main", "pooled_interaction", "separate_material"]
    b_pairs = [("pooled_main", "material_empirical"), ("pooled_interaction", "pooled_main"),
               ("separate_material", "pooled_main"), ("pooled_main", "constant"),
               ("separate_material", "pooled_interaction")]
    bm, bi, bp, bb = run_experiment("B", b, b_names, b_pairs)
    print("B completed", json.dumps(bm[bm.role.eq("later") & bm.material.eq("ALL")][["method", "n", "casualty_reports", "AP", "Brier"]].to_dict("records")), flush=True)
    timing = b[b.IGNITE_IND.eq("YES")]
    stage = b.groupby(["mat", "IGNITE_IND"]).agg(n=("cas", "size"), casualty_reports=("cas", "sum"),
                                                 ignition_time_nonblank=("IGNITE_DATETIME", lambda s: int(s.ne("").sum()))).reset_index()
    csv("B_stage_counts_descriptive_only.csv", stage)
    conclusions = {
        "scope": "Retrospective reported incident discrimination; not network incident probability, intervention effect, or field safety level",
        "A_later": {"n": int(a.role.eq("later").sum()), "casualty_reports": int(a.loc[a.role.eq("later"), "cas"].sum())},
        "B_later": {"n": int(b.role.eq("later").sum()), "casualty_reports": int(b.loc[b.role.eq("later"), "cas"].sum())},
        "B_refit_steel_positive_reports": int(b.loc[b.mat.eq("STEEL") & b.received_year.le(2021), "cas"].sum()),
        "B_independent_steel_model": "fitted once per early stage as a numerical feasibility demonstration; not a defensible independent deployment candidate",
        "B_model_selection": "No winner selected from later outcomes; retain pooled main and bounded interaction as unconfirmed candidates",
        "ignition_timestamp_coverage": {"ignited_reports": len(timing), "with_timestamp": int(timing.IGNITE_DATETIME.ne("").sum())},
        "bootstrap_A": ab, "bootstrap_B": bb,
        "uncertainty_limit": "Operator-cluster intervals are conditional on fixed fitted models. They omit training uncertainty; four later excavation positive reports do not support a precise superiority or noninferiority claim.",
        "source_snapshot_limit": "A final historical report snapshot does not prove field values were available at incident-time prediction; report received-year splitting cannot remove later revisions."}
    write_json("conclusions.json", conclusions)
    for item in inventory:
        assert sha(ROOT / item["path"]) == item["sha256"]
    assert sha(OUT / "experiment_card.md") == card_hash
    write_json("execution_receipt.json", {
        "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "script_sha256": sha(Path(__file__)), "experiment_card_sha256": card_hash,
        "input_hashes_unchanged": True, "seed": SEED,
        "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__},
        "source_readback": "Existing AP, Brier and categorical top-20-percent hits reproduce within 1e-12",
        "new_probability_check": "All new logistic scores equal manual expit(X beta) within 1e-12",
        "comparison_policy": "Same later rows within each experiment; no complete-case deletion; no resplitting or late-period tuning",
        "warning_capture": captured_warnings})


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    captured_warnings = []
    with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
        warnings.simplefilter("always")
        main()
        captured_warnings.extend(str(w.message) for w in caught)
    receipt = json.loads((OUT / "execution_receipt.json").read_text(encoding="utf-8"))
    receipt["warning_capture"] = captured_warnings
    write_json("execution_receipt.json", receipt)
