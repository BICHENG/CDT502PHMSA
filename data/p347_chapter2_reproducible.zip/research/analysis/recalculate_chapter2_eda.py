"""Recompute the three adopted EDA comparisons from the chapter-one dataset.

Run from any directory. Results are descriptive, fitted on the stated records;
no outcome, material, or winter flag enters either clustering matrix.
"""
from pathlib import Path
import hashlib
import json
import platform

import numpy as np
import pandas as pd
import sklearn
from sklearn.cluster import DBSCAN, KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "research/results/p347_ch2"
MATERIALS = ["CAST/WROUGHT IRON", "STEEL", "PLASTIC"]
SEED = 20261109


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def csv(frame, name):
    frame.to_csv(OUT / name, index=False, encoding="utf-8-sig")


def load_data():
    base = ROOT / "research/eda_pca"
    reports = pd.read_csv(base / "merged_incidents.csv", dtype={"REPORT_NUMBER": str})
    raw = pd.read_csv(base / "merged_components.csv", dtype={"REPORT_NUMBER": str})
    assert len(reports) == len(raw) == 1550
    assert reports.REPORT_NUMBER.is_unique and raw.REPORT_NUMBER.is_unique
    data = reports.merge(raw[["REPORT_NUMBER", "ACCIDENT_PSIG", "NORMAL_PSIG", "MOP_PSIG"]],
                         on="REPORT_NUMBER", validate="one_to_one").sort_values("REPORT_NUMBER").reset_index(drop=True)
    data["date"] = pd.to_datetime(data.LOCAL_DATETIME, format="mixed")
    data["month"] = data.date.dt.month
    data["winter"] = data.month.isin([11, 12, 1, 2, 3])
    data["cas"] = data.cas.astype(int)
    assert data.cas.sum() == 369
    scope = data.date.dt.year.between(2010, 2024) & data.SYSTEM_PART_INVOLVED.isin(["MAIN", "MAIN VALVE"]) & data.MATERIAL_INVOLVED.isin(MATERIALS)
    assert scope.sum() == 693 and data.loc[scope, "cas"].sum() == 141
    return data, scope


def excavation(data, scope):
    frame = data.loc[scope & data.CAUSE.eq("EXCAVATION DAMAGE") & data.MATERIAL_INVOLVED.isin(["STEEL", "PLASTIC"])].copy()
    frame["ignited"] = frame.IGNITE_IND.eq("YES")
    assert len(frame) == 391
    common_share = float(frame.ignited.mean())
    rows, cells = [], []
    for material in ["STEEL", "PLASTIC"]:
        part = frame.loc[frame.MATERIAL_INVOLVED.eq(material)]
        proportions = {}
        for ignited in [False, True]:
            cell = part.loc[part.ignited.eq(ignited)]
            proportions[ignited] = float(cell.cas.mean())
            cells.append(dict(material=material, ignited=ignited, reports=len(cell), casualty_reports=int(cell.cas.sum()), proportion=proportions[ignited]))
        rows.append(dict(material=material, reports=len(part), casualty_reports=int(part.cas.sum()),
                         observed_proportion=float(part.cas.mean()), ignition_share=float(part.ignited.mean()),
                         common_ignition_share=common_share,
                         common_mix_proportion=common_share * proportions[True] + (1 - common_share) * proportions[False]))
    result = pd.DataFrame(rows)
    csv(frame.drop(columns="date"), "excavation_records.csv")
    csv(pd.DataFrame(cells), "excavation_conditional_counts.csv")
    csv(result, "excavation_composition.csv")
    assert result.reports.tolist() == [196, 195] and result.casualty_reports.tolist() == [6, 35]
    return dict(n=391, common_ignition_share=common_share,
                raw_gap_percentage_points=float(np.diff(result.observed_proportion)[0] * 100),
                common_mix_gap_percentage_points=float(np.diff(result.common_mix_proportion)[0] * 100))


def natural_distance(frame, all_data, with_geography=False):
    """Four raw columns; geography is retained only as a controlled alternative."""
    dates = pd.to_datetime("2000-" + frame.date.dt.strftime("%m-%d"))
    day = dates.dt.dayofyear.to_numpy()
    difference = np.abs(day[:, None] - day[None, :])
    seasonal = np.minimum(difference, 366 - difference) / 45
    all_pressure = np.log1p(all_data[["NORMAL_PSIG", "MOP_PSIG"]].to_numpy(float))
    mean, sd = all_pressure.mean(0), all_pressure.std(0)
    pressure = (np.log1p(frame[["NORMAL_PSIG", "MOP_PSIG"]].to_numpy(float)) - mean) / sd
    site = frame.LOCATION_TYPE.to_numpy()
    terms = {"date_squared": seasonal ** 2,
             "site_squared": .2 * (site[:, None] != site[None, :]),
             "normal_pressure_squared": .1 * (pressure[:, 0, None] - pressure[None, :, 0]) ** 2,
             "allowed_pressure_squared": .1 * (pressure[:, 1, None] - pressure[None, :, 1]) ** 2}
    if with_geography:
        lat, lon = np.deg2rad(frame[["LOCATION_LATITUDE", "LOCATION_LONGITUDE"]].to_numpy(float)).T
        hav = np.sin((lat[:, None] - lat[None, :]) / 2) ** 2 + np.cos(lat[:, None]) * np.cos(lat[None, :]) * np.sin((lon[:, None] - lon[None, :]) / 2) ** 2
        geography = 2 * 6371.0088 * np.arcsin(np.sqrt(np.clip(hav, 0, 1))) / 1000
        terms["geography_squared"] = geography ** 2
    distance = np.sqrt(sum(terms.values()))
    np.fill_diagonal(distance, 0)
    assert np.isfinite(distance).all() and np.allclose(distance, distance.T)
    return distance, terms, dict(log1p_pressure_mean=mean.tolist(), log1p_pressure_population_sd=sd.tolist(),
                                 reference_year=2000, period_days=366, day_scale=45,
                                 geographical_distance_included=with_geography,
                                 site_squared_weight=.2, pressure_squared_weight=.1)


def dbscan_profile(frame, fit, eps, scope_name):
    profiles = []
    core = np.zeros(len(frame), dtype=bool)
    core[fit.core_sample_indices_] = True
    labels = sorted(set(fit.labels_) - {-1}, key=lambda x: -int((fit.labels_ == x).sum()))
    mapping = {label: number + 1 for number, label in enumerate(labels)}
    for label in labels:
        mask = fit.labels_ == label
        part = frame.loc[mask]
        profiles.append(dict(scope=scope_name, eps=eps, group=mapping[label], reports=len(part), core=int(core[mask].sum()),
                             border=int((~core[mask]).sum()), winter_reports=int(part.winter.sum()),
                             materials=part.MATERIAL_INVOLVED.value_counts().to_dict(),
                             months=part.month.value_counts().sort_index().to_dict(),
                             causes=part.CAUSE_DETAILS.value_counts().to_dict(),
                             operators=int(part.OPERATOR_ID.nunique()), casualty_reports=int(part.cas.sum()),
                             report_numbers=part.REPORT_NUMBER.tolist()))
    return profiles, core, np.array([mapping.get(x, -1) for x in fit.labels_])


def natural_clusters(data, scope):
    all_natural = data.loc[data.CAUSE.eq("NATURAL FORCE DAMAGE") & data.date.dt.year.between(2010, 2024)].copy().reset_index(drop=True)
    main = data.loc[scope & data.CAUSE.eq("NATURAL FORCE DAMAGE")].copy().reset_index(drop=True)
    assert len(main) == 42 and main.SYSTEM_PART_INVOLVED.eq("MAIN").all() and len(all_natural) == 106
    settings, all_profiles, geography_controls = [], [], []
    for scope_name, frame in [("main_42", main), ("all_natural_106", all_natural)]:
        distance, terms, scales = natural_distance(frame, data)
        geographical, _, _ = natural_distance(frame, data, with_geography=True)
        reference_fit = DBSCAN(metric="precomputed", eps=1 + 1e-12, min_samples=4).fit(geographical)
        reference_profiles, _, reference_labels = dbscan_profile(frame, reference_fit, 1, scope_name)
        geography_controls.append(dict(scope=scope_name, eps=1, min_samples=4, geography_scale_km=1000,
            groups=reference_profiles, noise=int((reference_labels < 0).sum())))
        for eps in [.8, 1., 1.2]:
            fit = DBSCAN(metric="precomputed", eps=eps + 1e-12, min_samples=4).fit(distance)
            profiles, core, group = dbscan_profile(frame, fit, eps, scope_name)
            all_profiles.extend(profiles)
            settings.append(dict(scope=scope_name, eps=eps, min_samples=4, reports=len(frame),
                                 groups=len(profiles), noise=int((group < 0).sum()),
                                 group_sizes=";".join(str(p["reports"]) for p in profiles)))
            if eps == 1:
                points = frame.copy()
                points["cluster"] = group
                points["point_role"] = np.where(group < 0, "noise", np.where(core, "core", "border"))
                points["neighbors_including_self"] = (distance <= 1 + 1e-12).sum(1)
                assert np.array_equal(core, points.neighbors_including_self.ge(4).to_numpy())
                csv(points.drop(columns="date"), "dbscan_" + scope_name + "_points.csv")
                if scope_name == "main_42":
                    assert [p["reports"] for p in profiles] == [21, 12, 7] and (group < 0).sum() == 2
                    assert profiles[0]["materials"] == {"CAST/WROUGHT IRON": 14, "STEEL": 7}
                    assert profiles[0]["winter_reports"] == 21 and profiles[0]["core"] == 21
                    pd.DataFrame(distance, index=frame.REPORT_NUMBER, columns=frame.REPORT_NUMBER).to_csv(OUT / "dbscan_distances.csv", encoding="utf-8-sig", index_label="REPORT_NUMBER")
                    neighbors = []
                    for i in range(len(frame)):
                        for j in range(i + 1, len(frame)):
                            neighbors.append(dict(report_i=frame.REPORT_NUMBER[i], report_j=frame.REPORT_NUMBER[j],
                                                  distance=float(distance[i, j]), is_neighbor=bool(distance[i, j] <= 1 + 1e-12),
                                                  **{key: float(term[i, j]) for key, term in terms.items()}))
                    csv(pd.DataFrame(neighbors), "dbscan_pair_terms.csv")
                    write_json(OUT / "dbscan_parameters.json", dict(raw_fields=["LOCAL_DATETIME", "LOCATION_TYPE", "NORMAL_PSIG", "MOP_PSIG"],
                        scope="42 natural-force MAIN reports; occurrence years 2010–2024; iron, steel, plastic",
                        eps=1, min_samples_including_self=4, pressure_scale_fit_n=len(data), **scales,
                        excluded_from_distance=["LOCATION_LATITUDE", "LOCATION_LONGITUDE", "MATERIAL_INVOLVED", "cas", "winter", "CAUSE_DETAILS"],
                        exploratory_status="Metric specified after prior monthly observations; descriptive grouping, not independent hypothesis confirmation",
                        display="Original month-day on an August-to-July axis and log1p normal pressure; clustering uses all four raw fields"))
    csv(pd.DataFrame(settings), "dbscan_sensitivity.csv")
    write_json(OUT / "dbscan_profiles.json", all_profiles)
    write_json(OUT / "dbscan_geography_control.json", geography_controls)
    return [p for p in all_profiles if p["scope"] == "main_42" and p["eps"] == 1]


def physical_clusters(data, scope):
    complete = scope & data.AGE_YEARS.notna() & data.AGE_YEARS.ge(0) & data.PIPE_DIAMETER.notna() & data.PIPE_DIAMETER.gt(0) & data.PRESSURE_PC1.notna()
    frame = data.loc[complete].copy().reset_index(drop=True)
    assert len(frame) == 621 and frame.SYSTEM_PART_INVOLVED.eq("MAIN").all()
    matrices = {"normal_pressure_reference": np.column_stack([frame.AGE_YEARS, np.log1p(frame.PIPE_DIAMETER), np.log1p(frame.NORMAL_PSIG)]),
                "common_pressure": np.column_stack([frame.AGE_YEARS, np.log1p(frame.PIPE_DIAMETER), frame.PRESSURE_PC1])}
    choices, labels = [], {}
    for name, values in matrices.items():
        scaler = StandardScaler().fit(values)
        matrix = scaler.transform(values)
        for k in range(2, 9):
            model = KMeans(n_clusters=k, random_state=SEED, n_init=50, max_iter=500, algorithm="lloyd").fit(matrix)
            choices.append(dict(input=name, k=k, reports=len(frame), silhouette=float(silhouette_score(matrix, model.labels_)), inertia=float(model.inertia_)))
            if k != 3:
                continue
            labels[name] = model.labels_.copy()
            if name != "common_pressure":
                continue
            old_group = max(range(3), key=lambda g: frame.loc[model.labels_ == g, "AGE_YEARS"].median())
            other = sorted(set(range(3)) - {old_group}, key=lambda g: frame.loc[model.labels_ == g, "PIPE_DIAMETER"].median())
            ordered = other + [old_group]
            mapping = {old: new + 1 for new, old in enumerate(ordered)}
            frame["cluster"] = [mapping[x] for x in model.labels_]
            frame[["age_z", "log1p_diameter_z", "pressure_pc1_z"]] = matrix
            frame["distance_to_center"] = np.linalg.norm(matrix - model.cluster_centers_[model.labels_], axis=1)
            centers = scaler.inverse_transform(model.cluster_centers_)
            center_rows, profiles = [], []
            names = ["较年轻／小口径", "较大口径", "高龄／低压"]
            for new, old in enumerate(ordered, 1):
                f = frame.loc[frame.cluster.eq(new)]
                center_rows.append(dict(cluster=new, name=names[new - 1], reports=len(f),
                    age_z=float(model.cluster_centers_[old, 0]), log1p_diameter_z=float(model.cluster_centers_[old, 1]), pressure_pc1_z=float(model.cluster_centers_[old, 2]),
                    center_age_years=float(centers[old, 0]), center_log1p_diameter=float(centers[old, 1]),
                    center_diameter_inches=float(np.expm1(centers[old, 1])), center_pressure_pc1=float(centers[old, 2])))
                for material in ["ALL", *MATERIALS]:
                    p = f if material == "ALL" else f.loc[f.MATERIAL_INVOLVED.eq(material)]
                    profiles.append(dict(cluster=new, name=names[new - 1], material=material, reports=len(p),
                        casualty_reports=int(p.cas.sum()), median_age_years=float(p.AGE_YEARS.median()),
                        median_diameter_inches=float(p.PIPE_DIAMETER.median()), median_normal_psig=float(p.NORMAL_PSIG.median()),
                        median_pressure_pc1=float(p.PRESSURE_PC1.median())))
            csv(pd.DataFrame(center_rows), "physical_centers.csv")
            csv(pd.DataFrame(profiles), "physical_profiles.csv")
            csv(frame.drop(columns="date"), "physical_points.csv")
            write_json(OUT / "physical_parameters.json", dict(input_fields=["AGE_YEARS", "PIPE_DIAMETER", "PRESSURE_PC1"],
                transforms=["identity", "log1p", "identity"], mean=scaler.mean_.tolist(), population_sd=scaler.scale_.tolist(),
                fit_n=621, scope="Descriptive EDA fitted on all 621 complete MAIN reports; no temporal prediction split",
                seed=SEED, n_init=50, max_iter=500, algorithm="lloyd", selected_k=3, display_group_order=ordered,
                centers_in_z=model.cluster_centers_.tolist(), outcome_and_material_used_for_fit=False))
    selection = pd.DataFrame(choices)
    assert selection.groupby("input").apply(lambda x: int(x.loc[x.silhouette.idxmax(), "k"]), include_groups=False).eq(3).all()
    csv(selection, "physical_k_selection.csv")
    ari = float(adjusted_rand_score(labels["normal_pressure_reference"], labels["common_pressure"]))
    assert abs(ari - .9575170674473307) < 1e-12
    selected = selection.loc[selection.k.eq(3)].to_dict("records")
    write_json(OUT / "physical_comparison.json", dict(ARI=ari, selected=selected,
               interpretation="Partition agreement describes retained facility structure, not casualty prediction performance"))
    return dict(n=621, k=3, group_sizes=frame.cluster.value_counts().sort_index().tolist(), ARI=ari, selected=selected)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    data, scope = load_data()
    result = dict(excavation=excavation(data, scope), dbscan=natural_clusters(data, scope), physical=physical_clusters(data, scope))
    inputs = [ROOT / "research/eda_pca/merged_incidents.csv", ROOT / "research/eda_pca/merged_components.csv"]
    result["provenance"] = dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__,
                                inputs={p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs})
    write_json(OUT / "run_receipt.json", result)
    print(json.dumps(dict(excavation=result["excavation"], dbscan_sizes=[p["reports"] for p in result["dbscan"]], physical=result["physical"]), ensure_ascii=False))


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        main()
