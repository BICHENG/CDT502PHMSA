Chapter 2 descriptive EDA reproduction

Install numpy, pandas, scikit-learn, threadpoolctl.
Run from the extracted directory:
python research/analysis/recalculate_chapter2_eda.py

Exact environment versions and input SHA256 values: research/results/p347_ch2/run_receipt.json
Material and casualty fields are used after clustering, not in either fitted distance.
